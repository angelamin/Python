int main() {
    int a;
    float b;
    int c;
    float e;
    c=10;
    q=5;
    if(c) {
        a = 1 + 10;
        b = 10.9 + 8.9;
    }
    b = 1.11 * 8.9;
    while(a) {
        b = 10.44;
        e = 990.45;
        c = 90;
    }
    c = 80;
}

int func1 () {
}
