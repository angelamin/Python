int func1 () {
	while(num!=100){num++;}
}
int main()/*the main function*/
{
	int a;
	float _b;
	int c12_354;
	int D[10];
	float e;
	c = 1e-8;
	if(c > 0) {
		a = 1.1 + 10;
		b = 10.9 + 8.9;
	}
	else {
		b = 1.11 * 8.9;
	}
	while(a) {
		b = 10.44;
		e = 990.45;
		c = 90;
	}
	while(){
	}
	c = 8 & 7;
	e = D[2];
	func1();
	func1(a);
	/*string s = "hello world!";*/
}