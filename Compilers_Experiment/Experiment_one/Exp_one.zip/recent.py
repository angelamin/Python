# -*- coding: utf-8 -*-
'''
Created on 2016-10-3

@author: xiamin
'''
import string

_key = ("auto", "break", "case", "char", "const", "continue", "default",

        "do", "double", "else", "enum", "extern", "float", "for",

        "goto", "if", "int", "long", "register", "return", "short",

        "signed", "static", "sizeof", "struct", "switch", "typedef", "union",

        "unsigned", "void", "volatile", "while")  # c语言的32个关键字

_abnormalChar = '@#$%^&*~'  # 标识符中可能出现的非法字符

_syn = ''  # 单词的种别码
_p = 0  # 下标
_value = ''  # 存放词法分析出的单词
_content = ''  # 程序内容
_mstate = 0  # 字符串的状态
_cstate = 0  # 字符的状态
_dstate = 0  # 整数和浮点数的状态
_line = 1  # 代码的第几行
_mysymbol = []  # 符号表


def outOfComment(mistakesFile):
    '''去除代码中的注释'''
    global _content
    state = 0
    index = -1
    _cline = 1
    ####--------------------------------将注释内容写到单独一个文件夹
    noteFile = open(r'/Users/xiamin/Downloads/Python_study/Compilers_Experiment/Experiment_one/temp3/note.txt', 'w')
    DFACommentFile = open(r'/Users/xiamin/Downloads/Python_study/Compilers_Experiment/Experiment_one/temp3/DFA_Comment.txt', 'r')
    line=DFACommentFile.next()
    for c in _content:
        if c == '\n':
            _cline += 1
        index = index + 1

        if state == 0:
            if c == '/':
                state = 1
                startIndex = index

        elif state == 1:
            if c == '*':
                state = 2
                _fline = _cline
            else:
                state = 0

        elif state == 2:
            if c == '*':
                state = 3
            else:
                pass


        elif state == 3:
            if c == '/':
                endIndex = index + 1
                comment = _content[startIndex:endIndex]
                noteFile.write(comment+'\n')   #----------------------------写入注释
                _content = _content.replace(comment, '')  # 将注释替换为空，并且将下标移动
                index = startIndex - 1
                state = 0

            elif c == '*':
                _fline = _cline
                pass
            else:
                state = 2
    ##--------------------------------注释内容有错，不闭合时，形成错误信息
    if state == 2 or state == 3:
        mistakesFile.write('注释 未闭合！Error in line '+str(_fline)+'\n') # ----------------------------写入注释
        comment=_content[startIndex:len(_content)]
        noteFile.write(comment+'\n')
        _content=_content.replace(comment,'')

def getMyProm():
    '''从文件中获取代码片段'''
    global _content
    myPro = open('/Users/xiamin/Downloads/Python_study/Compilers_Experiment/Experiment_one/temp3/test.txt', 'r')

    for line in myPro:
        if line != '\n':
            _content = "%s%s" % (_content, line.lstrip())  # 效率更高的字符串拼接方法
        else:
            _content = "%s%s" % (_content, line)
    myPro.close()


def analysis(mystr):
    '''分析目标代码，生成token'''
    global _p, _value, _syn, _mstate, _dstate, _line, _cstate

    _value = ''
    ch = mystr[_p]
    _p += 1
    while ch == ' ':
        ch = mystr[_p]
        _p += 1
    if ch in string.letters or ch == '_':  ###############letter(letter|digit)*
        while ch in string.letters or ch in string.digits or ch == '_' or ch in _abnormalChar:
            _value += ch
            ch = mystr[_p]
            _p += 1
        _p -= 1

        for abnormal in _abnormalChar:
            if abnormal in _value:
                _syn = '@-6'  # 错误代码，标识符中含有非法字符
                break
            else:
                _syn = 'IDN'     #IDN

        for s in _key:
            if cmp(s, _value) == 0:
                _syn = _value.upper()  #############关键字
                break
        if _syn == 'IDN':
            inSymbolTable(_value)

    elif ch == '\"':  #############字符串
        while ch in string.letters or ch in '\"% ':
            _value += ch
            if _mstate == 0:
                if ch == '\"':
                    _mstate = 1
            elif _mstate == 1:
                if ch == '\"':
                    _mstate = 2

            ch = mystr[_p]
            _p += 1

        if _mstate == 1:
            _syn = '@-2'  # 错误代码，字符串不封闭
            _mstate = 0

        elif _mstate == 2:
            _mstate = 0
            _syn = 'STRING'

        _p -= 1

    elif ch in string.digits:
        while ch in string.digits or ch == '.' or ch in string.letters:
            _value += ch
            if _dstate == 0:
                if ch == '0':
                    _dstate = 1
                else:
                    _dstate = 2

            elif _dstate == 1:
                if ch == '.':
                    _dstate = 3
                else:
                    _dstate = 5

            elif _dstate == 2:
                if ch == '.':
                    _dstate = 3

            ch = mystr[_p]
            _p += 1

        for char in string.letters:
            if char in _value:
                _syn = '@-7'  # 错误代码，数字和字母混合，如12AB56等
                _dstate = 0

        if _syn != '@-7':
            if _dstate == 5:
                _syn = '@-3'  # 错误代码，数字以0开头
                _dstate = 0
            else:
                _dstate = 0
                if '.' not in _value:
                    _syn = 'DIGIT'  ##################digit digit*
                else:
                    if _value.count('.') == 1:
                        _syn = 'FRACTION'  ################## 浮点数
                    else:
                        _syn = '@-5'  # 错误代码，浮点数中包含多个点，如1.2.3
        _p -= 1


    elif ch == '\'':  ################## 字符
        while ch in string.letters or ch in '@#$%&*\\\'\"':
            _value += ch
            if _cstate == 0:
                if ch == '\'':
                    _cstate = 1

            elif _cstate == 1:
                if ch == '\\':
                    _cstate = 2
                elif ch in string.letters or ch in '@#$%&*':
                    _cstate = 3

            elif _cstate == 2:
                if ch in 'nt':
                    _cstate = 3

            elif _cstate == 3:
                if ch == '\'':
                    _cstate = 4
            ch = mystr[_p]
            _p += 1

        _p -= 1
        if _cstate == 4:
            _syn = 'CHARACTER'
            _cstate = 0
        else:
            _syn = '@-4'  # 错误代码，字符不封闭
            _cstate = 0

    elif ch == '<':
        _value = ch
        ch = mystr[_p]

        if ch == '=':  ###########  '<='
            _value += ch
            _p += 1
            _syn = 'LE'
        else:  ###########  '<'
            _syn = 'L'

    elif ch == '>':
        _value = ch
        ch = mystr[_p]

        if ch == '=':  ########### '>='
            _value += ch
            _p += 1
            _syn = 'ME'
        else:  ########## '>'
            _syn = 'M'

    elif ch == '!':
        _value = ch
        ch = mystr[_p]

        if ch == '=':  ########## '!='
            _value += ch
            _p += 1
            _syn = 'NE'
        else:  ########## '!'
            _syn = 'N'


    elif ch == '+':
        _value = ch
        ch = mystr[_p]

        if ch == '+':  ############ '++'
            _value += ch
            _p += 1
            _syn = 'PP'
        else:  ############ '+'
            _syn = 'P'

    elif ch == '-':
        _value = ch
        ch = mystr[_p]

        if ch == '-':  ########### '--'
            _value += ch
            _p += 1
            _syn = 'DD'
        else:  ########### '-'
            _syn = 'D'

    elif ch == '=':
        _value = ch
        ch = mystr[_p]

        if ch == '=':  ########### '=='
            _value += ch
            _p += 1
            _syn = 'EE'
        else:  ########### '='
            _syn = 'E'

    elif ch == '&':
        _value = ch
        ch = mystr[_p]

        if ch == '&':  ########### '&&'
            _value += ch
            _p += 1
            _syn = 'UN'
        else:  ########### '&'
            _syn = 'AND'

    elif ch == '|':
        _value = ch
        ch = mystr[_p]

        if ch == '|':  ########## '||'
            _value += ch
            _p += 1
            _syn = 'OO'
        else:  ########## '|'
            _syn = 'O'

    elif ch == '*':  ########## '*'
        _value = ch
        _syn = 'MT'

    elif ch == '/':  ########## '/'
        _value = ch
        _syn = 'ST'

    elif ch == ';':  ########## ';'
        _value = ch
        _syn = 'SC'

    elif ch == '(':  ##########  '('
        _value = ch
        _syn = 'SLP'

    elif ch == ')':  ########### ')'
        _value = ch
        _syn = 'SRP'

    elif ch == '{':  ########### '{'
        _value = ch
        _syn = 'LP'

    elif ch == '}':  ########### '}'
        _value = ch
        _syn = 'RP'

    elif ch == '[':  ########### '['
        _value = ch
        _syn = 'ZLP'

    elif ch == ']':  ########### ']'
        _value = ch
        _syn = 'ZRP'

    elif ch == ',':  ########## ','
        _value = ch
        _syn = 'CM'
    elif ch == '\n':
        _syn = '@-1'


def inSymbolTable(token):
    '''将关键字和标识符存进符号表'''
    global _mysymbol
    if token not in _mysymbol:
        _mysymbol.append(token)


if __name__ == '__main__':
    symbolTableFile = open(r'/Users/xiamin/Downloads/Python_study/Compilers_Experiment/Experiment_one/temp3/symbol_table.txt', 'w')
    tokenFile = open(r'/Users/xiamin/Downloads/Python_study/Compilers_Experiment/Experiment_one/temp3/token.txt', 'w')
    mistakesFile = open(r'/Users/xiamin/Downloads/Python_study/Compilers_Experiment/Experiment_one/temp3/mistakes.txt','w')
    getMyProm()
    outOfComment(mistakesFile)


    while _p != len(_content):
        analysis(_content)
        if _syn == '@-1':
            _line += 1  # 记录程序的行数
        elif _syn == '@-2':
            mistakesFile.write('字符串 ' + _value + ' 不封闭! Error in line ' + str(_line)+'\n')
        elif _syn == '@-3':
            mistakesFile.write('数字 ' + _value + ' 错误，不能以0开头! Error in line ' + str(_line)+'\n')
        elif _syn == '@-4':
            mistakesFile.write('字符 ' + _value + ' 不封闭! Error in line ' + str(_line)+'\n')
        elif _syn == '@-5':
            mistakesFile.write('数字 ' + _value + ' 不合法! Error in line ' + str(_line)+'\n')
        elif _syn == '@-6':
            mistakesFile.write('标识符' + _value + ' 不能包含非法字符!Error in line ' + str(_line)+'\n')
        elif _syn == '@-7':
            mistakesFile.write('数字 ' + _value + ' 不合法,包含字母! Error in line ' + str(_line)+'\n')
        else:  # 若程序中无词法错误的情况
            if _syn == 'IDN':
                tokenFile.write(_value + '\t\t\t< ' + str(_syn) +' , '+ _value+' >\t' + '\n')
            elif _syn == 'DIGIT':
                tokenFile.write(_value + '\t\t\t< ' + str(_syn) +' , '+ _value+' >\t' + '\n')
            elif _syn == 'FRACTION':
                tokenFile.write(_value + '\t\t\t< ' + str(_syn) +' , '+ _value+' >\t' + '\n')
            else:
                tokenFile.write(_value+'\t\t\t< '+str(_syn)+' , '+'_'+' >\t'+'\n')

    tokenFile.close()
    symbolTableFile.write('入口地址\t变量名\n')
    i = 0
    for symbolItem in _mysymbol:
        symbolTableFile.write(str(i) + '\t\t\t' + symbolItem + '\n')
        i += 1
    symbolTableFile.close()